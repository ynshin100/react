import React from "react";
import "./Box.css";

const Box = ({ title, item, result }) => {
  //computer는 결과를 반전시켜서 출력
  if (title === "Computer" && result !== "Draw" && result !== "") {
    result = result === "Win" ? "Lose" : "Win";
  } else {
    result = result;
  }

  return (
    <div className={`box ${result}`}>
      <h1>{title}</h1>
      <img
        className="item-img"
        src={item && item.img}
        alt={item && item.name}
      />
      <h2>{result}</h2>
    </div>
  );
};

export default Box;

// const Box = ({ title, img, result }) => {
//   return (
//     <div className="box">
//       <h1>{title}</h1>
//       <img src={img} alt={title} />
//       <h2>{result}</h2>
//     </div>
//   );
// };

// export default Box;

//단락회로평가 - 부모로부터 item을 받아와야 이미지를 불러온다.
//논리 연산자를 사용하여 true일 때만...
