import { useState } from "react";
import "./App.css";
import Box from "./Box";

const choice = {
  scissors: {
    name: "scissors",
    img: "https://cdn.imweb.me/thumbnail/20230605/c357114a0d0c3.png",
  },
  rock: {
    name: "rock",
    img: "https://preview.free3d.com/img/2016/07/2206043479102981286/tydyzz2s.jpg",
  },
  paper: {
    name: "paper",
    img: "https://www.uniprint.ph/wp-content/uploads/2021/07/Tracing-Paper.jpg",
  },
};

function App() {
  const [userSelect, setuserSelect] = useState({});
  const [computerSelect, setcomputerSelect] = useState({});
  const [result, setResult] = useState("");

  const randomChoice = () => {
    let itemArray = Object.keys(choice);
    let randomItem = Math.floor(Math.random() * itemArray.length);
    let final = itemArray[randomItem];
    return choice[final];
  };

  const judgement = (user, computer) => {
    // console.log(user, computer);
    if (user.name === computer.name) {
      return "Draw";
    } else if (user.name === "rock") {
      return computer.name === "scissors" ? "Win" : "Lose";
    } else if (user.name === "scissors") {
      return computer.name === "paper" ? "Win" : "Lose";
    } else if (user.name === "paper") {
      return computer.name === "rock" ? "Win" : "Lose";
    }
  };

  const play = (userChoice) => {
    setuserSelect(choice[userChoice]);
    let computerChoice = randomChoice();
    setcomputerSelect(computerChoice);
    setResult(judgement(choice[userChoice], computerChoice));
  };
  // console.log("user ", userSelect);
  // console.log("COM ", computerSelect);

  return (
    <div className="App">
      <div className="main">
        <Box title="You" item={userSelect} result={result} />
        <Box title="Computer" item={computerSelect} result={result} />
      </div>
      <div className="main">
        <button onClick={() => play("scissors")}>가위</button>
        <button onClick={() => play("rock")}>바위</button>
        <button onClick={() => play("paper")}>보</button>
      </div>
    </div>
  );
}

export default App;

//--------내 코드---------//
// const arrayItem = Object.keys(choice);

// function App() {
//   const [userChoice, setUserChoice] = useState();
//   const [comChoice, setComChoice] = useState();
//   const [result, setResult] = useState("");

//   const checkWinner = () => {
//     if (
//       (userChoice === "scissors" && comChoice === "paper") ||
//       (userChoice === "rock" && comChoice === "scissors") ||
//       (userChoice === "paper" && comChoice === "rock")
//     ) {
//       setResult("Win!!");
//     } else if (userChoice === comChoice) {
//       setResult("Draw");
//     } else {
//       setResult("Lose..");
//     }
//   };

//   const comSelect = () => {
//     let comselectNumber = Math.floor(Math.random() * 3);
//     setComChoice(arrayItem[comselectNumber]);
//   };

//   const play = (userSelect) => {
//     setUserChoice(userSelect);
//     comSelect();
//     checkWinner();
//   };

//   return (
//     <div className="App">
//       <div className="main">
//         <Box title="You" result={result} />
//         <Box title="Computer" />
//       </div>
//       <div className="main">
//         <button onClick={() => play("scissors")}>가위</button>
//         <button onClick={() => play("rock")}>바위</button>
//         <button onClick={() => play("paper")}>보우</button>
//       </div>
//     </div>
//   );
// }

// export default App;
